import { motion } from "framer-motion";
import { ExternalLink, Github } from "lucide-react";

const projects = [
  {
    title: "E-Commerce Platform",
    desc: "A full-featured online store with real-time inventory, Stripe payments, and admin dashboard.",
    tags: ["React", "Node.js", "PostgreSQL"],
  },
  {
    title: "Task Management App",
    desc: "Collaborative project management tool with drag-and-drop boards and real-time sync.",
    tags: ["TypeScript", "Next.js", "Prisma"],
  },
  {
    title: "WEATHER FORECAST APP",
    desc: "beautiful weather application with loaction based forecasts and interactive maps",
    tags: ["React", "Python", "OpenAI"],
  },
  {
    title: "Analytics Dashboard",
    desc: "Real-time data visualization platform with customizable widgets and export features.",
    tags: ["React", "D3.js", "AWS"],
  },
];

const ProjectsSection = () => (
  <section id="projects" className="py-32 px-6">
    <div className="mx-auto max-w-6xl">
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
      >
        <p className="font-[family-name:var(--font-display)] text-sm tracking-widest text-primary uppercase mb-2">PROJECTS THAT I DID</p>
        <h2 className="text-3xl sm:text-4xl font-bold mb-12">
          Featured <span className="text-gradient">work</span>
        </h2>
      </motion.div>

      <div className="grid gap-6 sm:grid-cols-2">
        {projects.map((p, i) => (
          <motion.div
            key={p.title}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.12, duration: 0.5 }}
            className="group rounded-xl border border-border bg-gradient-card p-6 shadow-card transition-all hover:border-primary/30 hover:shadow-glow"
          >
            <h3 className="font-[family-name:var(--font-display)] text-xl font-semibold mb-3 group-hover:text-gradient transition-colors">
              {p.title}
            </h3>
            <p className="text-sm text-muted-foreground leading-relaxed mb-5">{p.desc}</p>
            <div className="flex items-center justify-between">
              <div className="flex flex-wrap gap-2">
                {p.tags.map((t) => (
                  <span key={t} className="rounded-md bg-secondary px-2.5 py-1 text-xs text-secondary-foreground">
                    {t}
                  </span>
                ))}
              </div>
              <div className="flex items-center gap-3 text-muted-foreground">
                <a href="#" className="hover:text-primary transition-colors"><Github size={16} /></a>
                <a href="#" className="hover:text-primary transition-colors"><ExternalLink size={16} /></a>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default ProjectsSection;
