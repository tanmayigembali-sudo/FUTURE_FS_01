import { motion } from "framer-motion";
import { ArrowDown } from "lucide-react";

const HeroSection = () => (
  <section id="home" className="relative flex min-h-screen items-center justify-center px-6">
    {/* Ambient glow */}
    <div className="pointer-events-none absolute top-1/4 left-1/2 -translate-x-1/2 h-[500px] w-[500px] rounded-full bg-primary/5 blur-[120px]" />

    <div className="relative z-10 max-w-3xl text-center">
      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mb-4 font-[family-name:var(--font-display)] text-sm tracking-widest text-primary uppercase"
      >
        Hello, I'm
      </motion.p>
      <motion.h1
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="text-5xl sm:text-7xl font-bold leading-tight tracking-tight"
      >
        <span className="text-foreground text-5xl">TANMAYI </span>
        <span className="text-gradient text-5xl">GEMBALI</span>
      </motion.h1>
      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="mt-6 text-lg text-muted-foreground max-w-xl mx-auto leading-relaxed"
      >
        A intern in full-stack developer crafting clean, performant, and delightful digital experiences.
      </motion.p>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.9 }}
        className="mt-10 flex items-center justify-center gap-4"
      >
        <a
          href="#projects"
          className="inline-flex items-center gap-2 rounded-lg bg-gradient-primary px-6 py-3 text-sm font-semibold text-accent-foreground transition-transform hover:scale-105"
        >
          View Projects
        </a>
        <a
          href="#contact"
          className="inline-flex items-center gap-2 rounded-lg border border-border px-6 py-3 text-sm font-semibold text-foreground transition-colors hover:border-primary hover:text-primary"
        >
          Contact Me
        </a>
      </motion.div>
    </div>

    <motion.a
      href="#about"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 1.2 }}
      className="absolute bottom-10 left-1/2 -translate-x-1/2 text-muted-foreground animate-bounce"
    >
      <ArrowDown size={20} />
    </motion.a>
  </section>
);

export default HeroSection;
