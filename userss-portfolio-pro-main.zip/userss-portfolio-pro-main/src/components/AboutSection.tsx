import { motion } from "framer-motion";
import { Code2, Palette, Zap } from "lucide-react";

const highlights = [
  { icon: Code2, title: "Clean Code", desc: "Writing maintainable, scalable solutions" },
  { icon: Palette, title: "Design-Driven", desc: "Pixel-perfect UI with great UX" },
  { icon: Zap, title: "Performance", desc: "Fast, optimized applications" },
];

const AboutSection = () => (
  <section id="about" className="py-32 px-6">
    <div className="mx-auto max-w-6xl">
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
      >
        <p className="font-[family-name:var(--font-display)] text-sm tracking-widest text-primary uppercase mb-2">About Me</p>
        <h2 className="text-3xl sm:text-4xl font-bold mb-8">
          Passionate about building <span className="text-gradient">projects</span>
        </h2>
        <p className="max-w-2xl text-muted-foreground leading-relaxed mb-12">
          I'm a developer building web applications. I love turning complex problems into simple, beautiful interfaces. When I'm not coding, you'll find me exploring new technologies and contributing to open source.
        </p>
      </motion.div>

      <div className="grid gap-6 sm:grid-cols-3">
        {highlights.map((h, i) => (
          <motion.div
            key={h.title}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.15, duration: 0.5 }}
            className="rounded-xl border border-border bg-gradient-card p-6 shadow-card transition-all hover:border-primary/30 hover:shadow-glow"
          >
            <h.icon className="mb-4 text-primary" size={28} />
            <h3 className="font-[family-name:var(--font-display)] text-lg font-semibold mb-2">{h.title}</h3>
            <p className="text-sm text-muted-foreground">{h.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default AboutSection;
