import { Github, Linkedin, Twitter } from "lucide-react";

const Footer = () => (
  <footer className="border-t border-border py-8 px-6">
    <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 sm:flex-row">
      <p className="text-xs text-muted-foreground">© 2026 John Doe. All rights reserved.</p>
      <div className="flex items-center gap-4 text-muted-foreground">
        <a href="#" className="hover:text-primary transition-colors"><Github size={18} /></a>
        <a href="#" className="hover:text-primary transition-colors"><Linkedin size={18} /></a>
        <a href="#" className="hover:text-primary transition-colors"><Twitter size={18} /></a>
      </div>
    </div>
  </footer>
);

export default Footer;
