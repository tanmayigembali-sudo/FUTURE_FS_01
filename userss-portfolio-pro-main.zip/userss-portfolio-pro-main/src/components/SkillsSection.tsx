import { motion } from "framer-motion";

const skills = [
  { name: "HTML/CSS", level: 95 },
  { name: "PYTHON", level: 90 },
  { name: "Node.js", level: 85 },
  { name: "JAVA", level: 92 },
  { name: "JAVA SCRIPT", level: 80 },
  { name: "GIT", level: 75 },
  { name: "GraphQL", level: 78 },
  { name: "AWS", level: 70 },
];

const SkillsSection = () => (
  <section id="skills" className="py-32 px-6">
    <div className="mx-auto max-w-4xl">
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
      >
        <p className="font-[family-name:var(--font-display)] text-sm tracking-widest text-primary uppercase mb-2">Skills</p>
        <h2 className="text-3xl sm:text-4xl font-bold mb-12">
          Technologies I <span className="text-gradient">work with</span>
        </h2>
      </motion.div>

      <div className="grid gap-6 sm:grid-cols-2">
        {skills.map((skill, i) => (
          <motion.div
            key={skill.name}
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.08, duration: 0.4 }}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="font-[family-name:var(--font-display)] text-sm font-medium">{skill.name}</span>
              <span className="text-xs text-muted-foreground">{skill.level}%</span>
            </div>
            <div className="h-2 w-full rounded-full bg-secondary overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                whileInView={{ width: `${skill.level}%` }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 + 0.3, duration: 0.8, ease: "easeOut" }}
                className="h-full rounded-full bg-gradient-primary"
              />
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default SkillsSection;
